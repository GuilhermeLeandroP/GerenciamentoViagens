package br.univille.projapifso2024a.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.univille.projapifso2024a.entity.Viagem;
import br.univille.projapifso2024a.service.ViagemService;

@RestController
@RequestMapping("/viagem")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ViagemController {
        
    @Autowired
    private ViagemService service;

    @CrossOrigin
    @GetMapping
    public ResponseEntity<List<Viagem>> getAll(){
        var listaViagens = service.getAll();
        return new ResponseEntity<List<Viagem>>(listaViagens,HttpStatus.OK);
    }

    @CrossOrigin
    @PostMapping
    public ResponseEntity<Viagem> post(@RequestBody Viagem Viagem){
        if(Viagem.getId() == 0){
            service.save(Viagem);
            return new ResponseEntity<Viagem>(Viagem, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    @CrossOrigin
    @PutMapping("/{id}")
    public ResponseEntity<Viagem> put(@PathVariable long id,
                                    @RequestBody Viagem Viagem){
        var ViagemAntigo = service.getById(id);
        if (ViagemAntigo == null){
            return ResponseEntity.notFound().build();
        }
        ViagemAntigo.setDestino(Viagem.getDestino());
        // ViagemAntigo.setResponsavel(Viagem.getResponsavel());
        ViagemAntigo.setSaida(Viagem.getSaida());
        // ViagemAntigo.setResponsavel(Viagem.getResponsavel());
        ViagemAntigo.setTransporte(Viagem.getTransporte());
        ViagemAntigo.setDataInicio(Viagem.getDataInicio());
        ViagemAntigo.setDataFim(Viagem.getDataFim());

        service.save(ViagemAntigo);
        return new ResponseEntity<Viagem>(ViagemAntigo, HttpStatus.OK);
    }

}
