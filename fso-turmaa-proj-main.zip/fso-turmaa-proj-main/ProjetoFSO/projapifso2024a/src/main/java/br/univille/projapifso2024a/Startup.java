package br.univille.projapifso2024a;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import br.univille.projapifso2024a.entity.Usuario;
import br.univille.projapifso2024a.service.UsuarioService;

@Component
public class Startup {
    @Autowired
    private UsuarioService service;

    @EventListener
    public void onApplicationEvent(ContextRefreshedEvent event){
        var usuarioPadrao = new Usuario();
        usuarioPadrao.setNome("Guilherme Leandro Pinto");
        usuarioPadrao.setEndereco("Rua Minas Gerais 100");
        usuarioPadrao.setDataNascimento(new Date(2024,04,17));
        usuarioPadrao.setSenha("panda@123");
        usuarioPadrao.setEmail("guilherme@univille.com");
        service.save(usuarioPadrao);
    }
}
