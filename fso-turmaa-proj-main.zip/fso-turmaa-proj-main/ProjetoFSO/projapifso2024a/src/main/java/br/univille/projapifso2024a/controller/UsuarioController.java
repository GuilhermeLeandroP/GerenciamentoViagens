package br.univille.projapifso2024a.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.univille.projapifso2024a.entity.Usuario;
import br.univille.projapifso2024a.service.UsuarioService;

@RestController
@RequestMapping("/usuario")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UsuarioController {
    
    @Autowired
    private UsuarioService service;

    @CrossOrigin
    @GetMapping
    public ResponseEntity<List<Usuario>> getAll(){
        var listaUsuarios = service.getAll();
        return new ResponseEntity<List<Usuario>>(listaUsuarios,HttpStatus.OK);
    }

    @CrossOrigin
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUser(@PathVariable long id){
        var user = service.getById(id);
        return new ResponseEntity<Usuario>(user,HttpStatus.OK);
    }

    @CrossOrigin
    @PostMapping
    public ResponseEntity<Usuario> post(@RequestBody Usuario usuario){
        if(usuario.getId() == 0){
            service.save(usuario);
            return new ResponseEntity<Usuario>(usuario, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    @CrossOrigin
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> put(@PathVariable long id,
                                    @RequestBody Usuario usuario){
        var usuarioAntigo = service.getById(id);
        if (usuarioAntigo == null){
            return ResponseEntity.notFound().build();
        }
        usuarioAntigo.setNome(usuario.getNome());
        usuarioAntigo.setEmail(usuario.getEmail());
        usuarioAntigo.setEndereco(usuario.getEndereco());
        usuarioAntigo.setDataNascimento(usuario.getDataNascimento());

        service.save(usuarioAntigo);
        return new ResponseEntity<Usuario>(usuarioAntigo, HttpStatus.OK);
    }

}
