package br.univille.projapifso2024a.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.projapifso2024a.entity.Usuario;
import br.univille.projapifso2024a.repository.UsuarioRepository;
import br.univille.projapifso2024a.service.UsuarioService;

@Service
public class UsuarioServiceImpl 
    implements UsuarioService {
    
    @Autowired
    private UsuarioRepository repository;
    
    @Override
    public void save(Usuario usuario) {
        repository.save(usuario);
    }

    @Override
    public Usuario getById(long id) {
        return repository.getById(id);
    }

    @Override
    public List<Usuario> getAll() {
        return repository.findAll();
    }
    
}
