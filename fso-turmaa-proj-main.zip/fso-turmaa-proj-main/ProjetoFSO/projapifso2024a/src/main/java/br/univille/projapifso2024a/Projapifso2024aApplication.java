package br.univille.projapifso2024a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projapifso2024aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projapifso2024aApplication.class, args);
	}

}
