package br.univille.projapifso2024a.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.projapifso2024a.entity.Viagem;
import br.univille.projapifso2024a.repository.ViagemRepository;
import br.univille.projapifso2024a.service.ViagemService;

@Service
public class ViagemServiceImpl implements ViagemService {
    
    @Autowired
    private ViagemRepository repository;

        
    @Override
    public void save(Viagem viagem) {
        repository.save(viagem);
    }

    @Override
    public Viagem getById(long id) {
        return repository.getById(id);
    }

    @Override
    public List<Viagem> getAll() {
        return repository.findAll();
    }
}
