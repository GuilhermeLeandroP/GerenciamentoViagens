package br.univille.projapifso2024a.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.univille.projapifso2024a.entity.Viagem;

@Repository
public interface ViagemRepository
    extends JpaRepository<Viagem, Long>{
    
}
