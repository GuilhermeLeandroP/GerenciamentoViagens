package br.univille.projapifso2024a.service;

import java.util.List;
import br.univille.projapifso2024a.entity.Viagem;

public interface ViagemService {
    void save(Viagem viagem);
    Viagem getById(long id);
    List<Viagem> getAll();
}
