package br.univille.projapifso2024a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projapifso2024aApplicationTests {

	@Test
	void contextLoads() {
	}

}
